# Validation record

Observed on 2026-09-13. These results describe the local demonstration, not production certification.

## Completed checks

| Check | Observed result |
|---|---|
| Windows Python suite | 26 passed |
| Linux container suite, isolated SQLite | 26 passed in 46.97 seconds |
| Linux container suite, dedicated PostgreSQL dvirs_test database | 26 passed in 52.16 seconds |
| Next.js production build and TypeScript | Passed, including four team routes |
| Final Docker Compose startup | Passed; migrations completed and runtime services started |
| HTTP smoke after backend replacement | Passed; 22 findings, top score 95 / P0, all application/team/API-doc routes accessible |
| Score explanation additivity | Every returned queue explanation reconciled to its score |
| Actual Celery asset-context event | Synthetic asset score 95 -> 85 -> 95 after restoration; five history entries |
| PostgreSQL runtime protection | Runtime role dvirs; all 21 UPDATE/DELETE/TRUNCATE privilege checks denied across seven append-only tables; triggers present |
| Actual Celery governed fixture | Completed; three inert markers and one explicitly synthetic detection match |
| Governance replay/deduplication | Reused authorization grant and duplicate detection evidence rejected |
| Governance self-check cleanup | Temporary scope revoked and operator disabled; synthetic evidence/audit retained |
| Offline fixture container | Built and ran successfully; emitted three inert JSON markers with network disabled |
| Model training/evaluation | XGBoost, logistic regression, Random Forest, LightGBM, gradient boosting, ensemble and Isolation Forest artifacts generated |

Tests cover scoring/additivity, source merge and temporal ordering, deduplication, CPE constraints,
authentication/RBAC, remediation, CSV/audit, independent scope approvals, one-use grants, revocation,
asset-context drift, detection deduplication and WebSocket authentication.

The final validation fixed two deployment issues found by live checks: stale Nginx service addresses
after container replacement and Celery child-process imports of the fixture package. The gateway
now refreshes service DNS and Celery launches as a Python module. A test-only allowed-origin setting
was also isolated from Compose configuration; deployment origins remain restricted.

## Model evidence

The held-out synthetic evaluation has 600 rows and 20% positive labels. The dynamic ensemble/rule
approach recorded Precision@50 0.66, ROC-AUC 0.7852 and synthetic workload reduction 0.4004 at 80%
recall. These are pipeline experiments, not estimates of real incident prediction or actual backlog
reduction. Local Windows and Linux artifacts carry distinct fitted-model fingerprints.

## Environmental observations and remaining validation

Windows Application Control blocks SHAP's native LLVM library in this environment. The application
uses its explicitly labeled portable permutation-Shapley fallback locally. The ensemble uses
permutation explanations by design. Native TreeSHAP remains an optional XGBoost path; the final
container suite exercised the ensemble.

The test output includes Starlette deprecation and LightGBM feature-name warnings; all assertions
passed. These warnings are retained rather than presented as a warning-free run.

The provided browser automation runtime reported no available browser. No visual screenshot,
interactive browser, responsive-layout or accessibility QA is claimed. Production frontend builds
and HTTP checks are distinct from browser validation.

The GitHub Actions workflow includes both live deployment checks but has not been run on GitHub.
No cloud project/account was selected and no hosted deployment or paid resources were created.
Production use still requires target-environment access controls, TLS, secret separation, backup
restoration, dependency review, load testing and validation using real labeled data. See
[updated scope](updated-scope.md) for requested capabilities outside this implementation.