"""Fixed, benign telemetry fixtures. This catalog contains no executable attacks."""
PLAYBOOKS = {
    'process-telemetry': {
        'name':'Process telemetry validation','technique':'T1059',
        'sensor':'process_creation','event_type':'synthetic.process.marker',
        'description':'Emit inert process-observation markers to validate a correlation pipeline. No process is launched.',
        'expected_detection':'A test-tagged process observation is ingested and linked to the exercise.'},
    'authentication-telemetry': {
        'name':'Authentication telemetry validation','technique':'T1110',
        'sensor':'authentication','event_type':'synthetic.authentication.marker',
        'description':'Emit test authentication-failure records. No login attempts or password guesses occur.',
        'expected_detection':'A test-tagged authentication observation is ingested and linked to the exercise.'},
    'network-telemetry': {
        'name':'Network telemetry validation','technique':'T1071',
        'sensor':'network_connection','event_type':'synthetic.network.marker',
        'description':'Emit inert periodic-connection records. No socket, DNS request, C2 channel, or outbound traffic is created.',
        'expected_detection':'A test-tagged network observation is ingested and linked to the exercise.'},
}
