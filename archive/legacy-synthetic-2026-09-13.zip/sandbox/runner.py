"""Offline deterministic fixture generator. No subprocesses, sockets, or sample execution."""
import argparse
import json
import uuid
from datetime import datetime, timezone
try:
    from .catalog import PLAYBOOKS
except ImportError:
    from catalog import PLAYBOOKS


def generate(playbook_id, exercise_id, asset_id, timestamp=None):
    playbook=PLAYBOOKS[playbook_id]
    timestamp=timestamp or datetime.now(timezone.utc).isoformat()
    return [{
        'id':str(uuid.uuid5(uuid.NAMESPACE_URL,f'dvirs:{exercise_id}:{index}')),
        'exercise_id':exercise_id,'asset_id':asset_id,'technique':playbook['technique'],
        'event_type':playbook['event_type'],'occurred_at':timestamp,
        'payload':{'synthetic':True,'sensor':playbook['sensor'],'sequence':index,
                   'marker':'DVIRS-BENIGN-VALIDATION','expected_detection':playbook['expected_detection']}
    } for index in range(3)]


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--playbook',choices=list(PLAYBOOKS),default='process-telemetry')
    parser.add_argument('--exercise-id',default='offline-fixture')
    parser.add_argument('--asset-id',default='offline-lab')
    args=parser.parse_args()
    print(json.dumps({'mode':'synthetic-telemetry-only','events':generate(args.playbook,args.exercise_id,args.asset_id)},indent=2))
