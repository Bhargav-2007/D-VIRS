import json
from pathlib import Path
from sqlalchemy import select
from backend.app.config import settings
from backend.app.database.connection import SessionLocal
from backend.app.models.schema import User, ModelRegistry, Vulnerability, Finding
from backend.app.api.security import hasher
from backend.app.api.schemas import AssetInput
from backend.app.services.ingestion import ingest
from backend.app.services.asset import upsert_asset, match_assets
from backend.app.services.scoring import rescore
from backend.app.services.events import record_change
from backend.app.ml.predict import artifact


def seed():
    config = settings()
    with SessionLocal.begin() as db:
        if not db.get(User, 'admin'):
            db.add(User(id='admin', role='admin', password_hash=hasher.hash(config.secret('admin_password'))))
        model = artifact()
        if model and not db.get(ModelRegistry, model['version']):
            db.add(ModelRegistry(version=model['version'], metadata_json=json.loads(config.model_path.with_suffix('.json').read_text())))
        if not config.demo_mode:
            demo_user = db.get(User, "demo-viewer")
            if demo_user: demo_user.active = False
            return
        if not db.get(User, 'demo-viewer'):
            db.add(User(id='demo-viewer', role='viewer', password_hash=hasher.hash(config.secret('admin_password')+'demo')))
        if db.scalar(select(Vulnerability.id).limit(1)):
            for finding_id in db.scalars(select(Finding.id).where(Finding.status == 'open')):
                record_change(db,'finding.changed',finding_id,'deployment','Deployment model reconciliation')
            return
        for source, file in [('normalized','data/cve/demo.json'), ('epss','data/epss/demo.json'),
                             ('kev','data/kev/demo.json'), ('exploit','data/threat_intelligence/demo.json')]:
            ingest(db, source, json.loads(Path(file).read_text()), 'demo-seed')
        for row in json.loads(Path('data/assets/demo.json').read_text()):
            upsert_asset(db, AssetInput(**row), 'demo-seed')
        match_assets(db)
        for finding_id in db.scalars(select(Finding.id).order_by(Finding.id)):
            rescore(db, finding_id, 'demo-seed', 'Initial synthetic demonstration')
    print('Database initialized. Demo data are synthetic; explanations are computed by the scoring engine.')

if __name__ == '__main__': seed()
