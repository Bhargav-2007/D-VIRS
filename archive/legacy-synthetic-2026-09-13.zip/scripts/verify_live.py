"""Verify a reversible context event through the running demo's actual worker queue."""
import json
import time
import httpx
from backend.app.config import settings


def run():
    config=settings()
    if not config.demo_mode: raise RuntimeError('Live demo verification requires DEMO_MODE=true')
    with httpx.Client(base_url='http://gateway',timeout=30) as client:
        login=client.post('/api/auth/token',data={'username':'admin','password':config.secret('admin_password')})
        login.raise_for_status()
        assets=client.get('/api/assets').json()['items']
        original=next(a for a in assets if a['id']=='asset-001')
        body={k:v for k,v in original.items() if k not in ('version','updated_at')}
        first=next(f for f in client.get('/api/scoring/queue').json()['items'] if f['asset_id']==body['id'] and f['cve_id']=='CVE-2026-90001')
        def wait_score(previous):
            deadline=time.monotonic()+45
            while time.monotonic()<deadline:
                current=next(f for f in client.get('/api/scoring/queue').json()['items'] if f['id']==first['id'])
                if current['score'] != previous: return current
                time.sleep(1)
            raise AssertionError('Worker did not publish a changed score within 45 seconds')
        try:
            response=client.put('/api/assets/'+body['id'],json={**body,'internet_facing':not body['internet_facing']})
            response.raise_for_status()
            changed=wait_score(first['score'])
        finally:
            client.put('/api/assets/'+body['id'],json=body).raise_for_status()
        restored=wait_score(changed['score'])
        assert restored['score']==first['score']
        history=client.get('/api/scoring/findings/'+first['id']+'/history').json()
        assert len(history)>=3
        return {'status':'passed','before':first['score'],'changed':changed['score'],'restored':restored['score'],
                'history_entries':len(history),'explanation_method':restored['explanation']['method']}

if __name__=='__main__': print(json.dumps(run(),indent=2))
