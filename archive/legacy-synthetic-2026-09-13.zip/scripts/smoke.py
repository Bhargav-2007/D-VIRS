"""Read-only smoke check against a running, seeded demo stack."""
import argparse
import json
import httpx

def smoke(url):
    with httpx.Client(base_url=url,timeout=60) as client:
        client.get('/api/health/ready').raise_for_status()
        response=client.post('/api/auth/demo')
        response.raise_for_status()
        queue=client.get('/api/scoring/queue').json()
        assert queue['total']>0, 'Demo finding queue is empty'
        for finding in queue['items']:
            e=finding['explanation']
            total=e['baseline_points']+e['override_points']+sum(x['total_points'] for x in e['contributions'])
            assert abs(total-finding['score'])<0.0002, 'Explanation does not reconcile'
        for route in ['/','/queue','/assets','/analytics','/vulnerabilities','/settings','/teams/red','/teams/blue','/teams/purple','/teams/white','/api/docs','/api/openapi.json']:
            client.get(route).raise_for_status()
        return {'status':'passed','findings':queue['total'],'top_score':queue['items'][0]['score'],
                'top_priority':queue['items'][0]['priority'],'checked':'HTTP routes, authentication, nonempty queue, score additivity'}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--url',default='http://localhost:8088')
    args=parser.parse_args()
    print(json.dumps(smoke(args.url),indent=2))
