"""Run integration tests only in this Compose project's dedicated dvirs_test database."""
import os
import subprocess
import sys
import psycopg
from backend.app.config import settings


if __name__=='__main__':
    config=settings()
    if not config.demo_mode:raise SystemExit('This helper only runs in a local demo deployment')
    password=config.secret('db_password')
    with psycopg.connect(host='postgres',user='dvirs_migrator',password=password,dbname='postgres',autocommit=True) as connection:
        if not connection.execute("SELECT 1 FROM pg_database WHERE datname='dvirs_test'").fetchone():
            connection.execute('CREATE DATABASE dvirs_test')
    environment={**os.environ,'TEST_DATABASE_URL':'postgresql+psycopg://dvirs_migrator:'+password+'@postgres:5432/dvirs_test'}
    raise SystemExit(subprocess.call([sys.executable,'-m','pytest','backend/tests','-q'],env=environment))
