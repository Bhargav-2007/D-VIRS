"""Exercise only synthetic demo governance through the actual PostgreSQL/Celery stack."""
import json
import secrets
import time
from datetime import datetime, timedelta, timezone
import httpx
from backend.app.config import settings


def run():
    config=settings()
    if not config.demo_mode: raise RuntimeError('Only the synthetic local demo is supported')
    actor='verify-'+secrets.token_hex(5)
    password=secrets.token_urlsafe(24)
    scope_id=None
    created=False
    with httpx.Client(base_url='http://gateway',timeout=30) as admin, httpx.Client(base_url='http://gateway',timeout=30) as operator:
        admin.post('/api/auth/token',data={'username':'admin','password':config.secret('admin_password')}).raise_for_status()
        try:
            admin.post('/api/auth/users',json={'id':actor,'password':password,'role':'purple'}).raise_for_status()
            created=True
            operator.post('/api/auth/token',data={'username':actor,'password':password}).raise_for_status()
            assets=admin.get('/api/assets').json()['items']
            asset=next(a for a in assets if a['environment'] in ('dev','test') and not a['internet_facing'])
            stamp=datetime.now(timezone.utc)
            response=operator.post('/api/governance/scopes',json={
                'name':'Synthetic deployment self-check','asset_ids':[asset['id']],'operator_ids':[actor],
                'playbook_ids':['process-telemetry'],'rules_of_engagement':'Automated demo pipeline test only. Emit inert synthetic markers; no target execution or network traffic.',
                'starts_at':(stamp-timedelta(seconds=5)).isoformat(),'expires_at':(stamp+timedelta(minutes=10)).isoformat()})
            response.raise_for_status();scope_id=response.json()['id']
            admin.post('/api/governance/scopes/'+scope_id+'/decisions',json={'decision':'approve','reason':'Synthetic local deployment self-check only; this is not real assessment authorization.'}).raise_for_status()
            response=operator.post('/api/governance/scopes/'+scope_id+'/grants',json={'asset_id':asset['id'],'playbook_id':'process-telemetry'})
            response.raise_for_status();token=response.json()['authorization_token']
            response=operator.post('/api/governance/exercises',json={'authorization_token':token})
            response.raise_for_status();exercise_id=response.json()['id']
            assert operator.post('/api/governance/exercises',json={'authorization_token':token}).status_code==409
            deadline=time.monotonic()+45
            while True:
                response=operator.get('/api/governance/exercises/'+exercise_id)
                response.raise_for_status();detail=response.json()
                if detail['status']=='completed':break
                assert detail['status']!='cancelled',detail
                if time.monotonic()>deadline:raise AssertionError('Exercise worker timed out')
                time.sleep(1)
            assert len(detail['telemetry'])==3
            event=detail['telemetry'][0]
            detection={'telemetry_id':event['id'],'source':'deployment-self-check','external_id':actor,
                'provenance':'synthetic','evidence':'Synthetic exact-ID pipeline match only; not evidence of actual detector effectiveness.',
                'detected_at':datetime.now(timezone.utc).isoformat()}
            operator.post('/api/governance/detections',json=detection).raise_for_status()
            assert operator.post('/api/governance/detections',json=detection).status_code==409
            return {'status':'passed','telemetry_markers':3,'synthetic_detection_matches':1,'grant_replay':'denied','duplicate_evidence':'denied'}
        finally:
            if scope_id:
                admin.post('/api/governance/scopes/'+scope_id+'/decisions',json={'decision':'revoke','reason':'Synthetic deployment self-check finished; retire its temporary scope.'}).raise_for_status()
            if created:
                admin.patch('/api/auth/users/'+actor,json={'role':'purple','active':False}).raise_for_status()


if __name__=='__main__': print(json.dumps(run(),indent=2))