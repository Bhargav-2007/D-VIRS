import json
from sqlalchemy import select, func
from backend.app.database.connection import SessionLocal
from backend.app.models.schema import RiskScore, AuditLog, Outbox, User
from backend.app.workers import process_event

ASSET={'id':'test-edge','hostname':'edge.example.test','criticality':5,'internet_facing':True,'team':'Platform',
       'software':[{'vendor':'demo','product':'web','version':'1.0'}]}
VULN={'id':'CVE-2026-12345','cvss_v3':7.5,'epss':.1,'affected_products':[{'vendor':'demo','product':'web','version':'1.0'}]}


def seed(client,headers):
    assert client.post('/api/assets',json=ASSET,headers=headers).status_code == 201
    response=client.post('/api/intelligence/ingest',json={'source':'normalized','payload':{'data':[VULN]}},headers=headers)
    assert response.status_code == 202, response.text
    queue=client.get('/api/scoring/queue',headers=headers).json()
    assert queue['total']==1
    return queue['items'][0]


def test_auth_required_rbac_and_revocation(client,auth):
    assert client.get('/api/assets').status_code == 401
    viewer=auth('viewer')
    assert client.post('/api/assets',json=ASSET,headers=viewer).status_code == 403
    assert client.get('/api/assets',headers=viewer).status_code == 200
    with SessionLocal.begin() as db: db.get(User,'viewer').active=False
    assert client.get('/api/assets',headers=viewer).status_code == 401


def test_event_pipeline_targeted_idempotent_and_remediation(client,auth):
    headers=auth()
    initial=seed(client,headers)
    with SessionLocal() as db:
        count=db.scalar(select(func.count()).select_from(RiskScore))
        event_id=db.scalar(select(Outbox.id).where(Outbox.kind=='vulnerability.changed'))
    process_event.run(event_id)
    with SessionLocal() as db: assert db.scalar(select(func.count()).select_from(RiskScore))==count
    kev={'source':'kev','payload':{'vulnerabilities':[{'cveID':VULN['id'],'dueDate':'2026-12-01'}]}}
    assert client.post('/api/intelligence/ingest',json=kev,headers=headers).status_code==202
    current=client.get('/api/scoring/queue',headers=headers).json()['items'][0]
    assert current['priority']=='P0' and current['score']>=95 and current['score']>initial['score']
    history=client.get('/api/scoring/findings/'+current['id']+'/history',headers=headers).json()
    assert len(history)==2 and history[0]['actor']=='admin'
    simulation=client.post('/api/analytics/simulate',headers=headers,json={'finding_ids':[current['id'],current['id']]}).json()
    assert simulation['after']==0 and simulation['findings_remediated']==1
    assert client.patch('/api/scoring/findings/'+current['id'],headers=headers,json={'status':'remediated','evidence':'CHG-123 verified fixed version'}).status_code==200
    assert client.get('/api/scoring/queue',headers=headers).json()['total']==0
    assert len(client.get('/api/scoring/findings/'+current['id']+'/history',headers=headers).json())==2


def test_asset_exposure_reprioritizes_only_affected_pairs(client,auth):
    headers=auth()
    first=seed(client,headers)
    second_asset={**ASSET,'id':'internal-two','hostname':'internal.example.test','criticality':2,'internet_facing':False}
    assert client.post('/api/assets',json=second_asset,headers=headers).status_code==201
    before=client.get('/api/scoring/queue',headers=headers).json()['items']
    with SessionLocal() as db: count=db.scalar(select(func.count()).select_from(RiskScore))
    second_asset['internet_facing']=True
    assert client.put('/api/assets/internal-two',json=second_asset,headers=headers).status_code==200
    with SessionLocal() as db: assert db.scalar(select(func.count()).select_from(RiskScore))==count+1


def test_validation_atomicity_csrf_and_policy(client,auth):
    headers=auth()
    assert client.post('/api/assets',headers=headers,json={**ASSET,'criticality':99}).status_code==422
    response=client.post('/api/intelligence/ingest',headers=headers,json={'source':'normalized','payload':{'data':[VULN,{'id':'bad'}]}})
    assert response.status_code==422
    assert client.get('/api/vulnerabilities',headers=headers).json()['total']==0
    assert client.post('/api/assets',headers={**headers,'Origin':'https://evil.example'},json=ASSET).status_code==403
    assert client.put('/api/scoring/policy',headers=headers,json={'weights':{},'thresholds':{'P0':10,'P1':20,'P2':40},'ml_weight':.8}).status_code==422


def test_csv_import_export_and_audit(client,auth):
    import csv,io
    headers=auth()
    stream=io.StringIO();writer=csv.DictWriter(stream,fieldnames=list(ASSET))
    writer.writeheader();writer.writerow({**ASSET,'software':json.dumps(ASSET['software'])})
    result=client.post('/api/assets/import/csv',headers=headers,files={'file':('assets.csv',stream.getvalue(),'text/csv')})
    assert result.status_code==200, result.text
    client.post('/api/intelligence/ingest',json={'source':'normalized','payload':{'data':[VULN]}},headers=headers)
    report=client.get('/api/reports/queue.csv',headers=headers)
    assert report.status_code==200 and VULN['id'] in report.text
    audit=client.get('/api/reports/audit',headers=headers).json()
    assert any(x['action']=='score.created' for x in audit)
    assert any(x['action']=='http.request' for x in audit)


def test_immutable_history(client,auth):
    import pytest
    row=seed(client,auth())
    with SessionLocal() as db:
        score=db.scalar(select(RiskScore))
        score.score=0
        with pytest.raises(ValueError,match='Append-only'): db.commit()
        db.rollback()


def test_login_rate_limit_and_bad_credentials(client):
    for _ in range(10):
        assert client.post('/api/auth/token',data={'username':'absent','password':'wrong'}).status_code==401
    assert client.post('/api/auth/token',data={'username':'absent','password':'wrong'}).status_code==429


def test_openapi_and_health(client):
    assert client.get('/api/health/ready').status_code==200
    assert client.get('/api/openapi.json').status_code==200
