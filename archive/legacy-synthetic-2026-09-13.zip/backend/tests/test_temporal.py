from backend.app.database.connection import SessionLocal
from backend.app.models.schema import Vulnerability
from backend.app.services.ingestion import ingest


def test_older_epss_cannot_overwrite_newer_source_revision():
    with SessionLocal.begin() as db:
        def payload(value,date):
            return {'data':[{'cve':'CVE-2026-12345','epss':value,'percentile':.9,'date':date}]}
        ingest(db,'epss',payload(.8,'2026-09-10'),'test')
        result=ingest(db,'epss',payload(.1,'2026-09-09'),'test')
        assert result['skipped']==1
        assert db.get(Vulnerability,'CVE-2026-12345').epss==.8
