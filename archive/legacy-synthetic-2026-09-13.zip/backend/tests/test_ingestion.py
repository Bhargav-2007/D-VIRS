from types import SimpleNamespace
from sqlalchemy import select, func
from backend.app.database.connection import SessionLocal
from backend.app.models.schema import Vulnerability, IntelligenceRecord, Outbox
from backend.app.services.ingestion import ingest
from backend.app.services.asset import matches_criteria, applicable
from backend.app.services.nvd import normalize


def test_partial_feeds_preserve_other_source_fields_and_deduplicate():
    payload = {'data':[{'id':'CVE-2026-12345','cvss_v3':9.8,'description':'fixture'}]}
    with SessionLocal.begin() as db:
        assert ingest(db,'normalized',payload,'test')['changed'] == ['CVE-2026-12345']
        assert ingest(db,'normalized',payload,'test')['skipped'] == 1
        ingest(db,'epss',{'data':[{'cve':'CVE-2026-12345','epss':.5,'percentile':.9}]},'test')
        v = db.get(Vulnerability,'CVE-2026-12345')
        assert v.cvss_v3 == 9.8 and v.epss == .5 and v.description == 'fixture'
        assert db.scalar(select(func.count()).select_from(IntelligenceRecord)) == 2
        assert db.scalar(select(func.count()).select_from(Outbox)) == 2


def test_nvd_v4_and_cwe_normalization():
    payload={'vulnerabilities':[{'cve':{'id':'CVE-2026-12345','published':'2026-01-02T00:00:00.000',
        'descriptions':[{'lang':'en','value':'fixture'}],
        'metrics':{'cvssMetricV40':[{'type':'Primary','cvssData':{'baseScore':8.4}}]},
        'weaknesses':[{'description':[{'value':'CWE-79'}]}]}}]}
    row=list(normalize(payload))[0]
    assert row['cvss_v4'] == 8.4 and row['cwes'] == ['CWE-79']


def test_cpe_exact_range_and_ambiguous_versions():
    criteria={'criteria':'cpe:2.3:a:demo:web:*:*:*:*:*:*:*:*','versionStartIncluding':'1.0','versionEndExcluding':'2.0'}
    assert matches_criteria({'vendor':'demo','product':'web','version':'1.8'},criteria)
    assert not matches_criteria({'vendor':'demo','product':'web','version':'2.0'},criteria)
    assert not matches_criteria({'vendor':'demo','product':'web','version':'vendor-build-seven'},criteria)


def test_cpe_and_requires_platform():
    vuln=SimpleNamespace(affected_products=[],configurations=[{'operator':'AND','nodes':[
        {'cpeMatch':[{'criteria':'cpe:2.3:a:demo:web:1.0:*:*:*:*:*:*:*'}]},
        {'cpeMatch':[{'criteria':'cpe:2.3:o:demo:os:2.0:*:*:*:*:*:*:*'}]}]}])
    asset=SimpleNamespace(software=[{'vendor':'demo','product':'web','version':'1.0'}])
    assert not applicable(vuln,asset)
    asset.software.append({'vendor':'demo','product':'os','version':'2.0'})
    assert applicable(vuln,asset)
