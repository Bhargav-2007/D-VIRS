import os
import secrets
import tempfile
from pathlib import Path

_test_dir = Path(tempfile.mkdtemp(prefix='dvirs-tests-'))
provided = os.getenv('TEST_DATABASE_URL')
if provided and not provided.rstrip('/').endswith('dvirs_test'):
    raise RuntimeError('TEST_DATABASE_URL must reference the dedicated dvirs_test database')
os.environ['DATABASE_URL'] = provided or 'sqlite:///' + str(_test_dir/'test.db').replace('\\','/')
os.environ['JWT_SECRET'] = secrets.token_hex(32)
os.environ['DEMO_MODE'] = 'true'
os.environ['EAGER_TASKS'] = 'true'
os.environ['COOKIE_SECURE'] = 'false'
os.environ['ALLOWED_ORIGINS'] = 'http://localhost:3000'
os.environ['RATE_LIMIT'] = '10000'

import pytest
from fastapi.testclient import TestClient
from backend.app.database.connection import Base, engine, SessionLocal
from backend.app.models.schema import User
from backend.app.api.security import hasher
from backend.app.main import app, local_buckets

PASSWORD = secrets.token_urlsafe(24)


@pytest.fixture(autouse=True)
def database():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    local_buckets.clear()
    with SessionLocal.begin() as db:
        for role in ('admin','analyst','viewer','red','blue','purple','white'):
            db.add(User(id=role, role=role, password_hash=hasher.hash(PASSWORD)))
    yield


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture
def auth(client):
    def token(role='admin'):
        response = client.post('/api/auth/token', data={'username':role,'password':PASSWORD})
        assert response.status_code == 200, response.text
        client.cookies.clear()
        return {'Authorization':'Bearer '+response.json()['access_token']}
    return token
