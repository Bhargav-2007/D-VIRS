import pytest
from starlette.websockets import WebSocketDisconnect


def test_websocket_rejects_untrusted_origin(client):
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect('/api/ws',headers={'origin':'https://evil.example'}):
            pass


def test_websocket_authentication_handshake(client,auth):
    token=auth('viewer')['Authorization'].split(' ',1)[1]
    with client.websocket_connect('/api/ws',headers={'origin':'http://localhost:3000'}) as ws:
        ws.send_json({'token':token})
        assert ws.receive_json()['type']=='connected'
        ws.close()


def test_bad_websocket_token_is_closed(client):
    with client.websocket_connect('/api/ws') as ws:
        ws.send_json({'token':'invalid'})
        with pytest.raises(WebSocketDisconnect):
            ws.receive_json()
