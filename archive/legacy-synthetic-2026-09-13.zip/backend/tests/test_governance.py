from datetime import timedelta
from sqlalchemy import select
from backend.app.database.connection import now, SessionLocal
from backend.app.models.schema import Outbox
from backend.app.models.governance import Exercise
from backend.app.workers import process_event, config

LAB={'id':'lab-01','hostname':'lab.example.test','environment':'test','internet_facing':False,
     'criticality':2,'software':[]}


def setup_scope(client,auth):
    admin=auth('admin');red=auth('red');white=auth('white')
    assert client.post('/api/assets',headers=admin,json=LAB).status_code==201
    body={'name':'Authorized telemetry test','asset_ids':['lab-01'],'operator_ids':['red'],
          'playbook_ids':['process-telemetry'],'rules_of_engagement':'Only inert synthetic markers; no target-side execution or network traffic.',
          'starts_at':(now()-timedelta(minutes=1)).isoformat(),'expires_at':(now()+timedelta(hours=1)).isoformat()}
    response=client.post('/api/governance/scopes',headers=red,json=body)
    assert response.status_code==201,response.text
    return response.json()['id'],admin,red,white


def approve(client,scope,white):
    r=client.post('/api/governance/scopes/'+scope+'/decisions',headers=white,
        json={'decision':'approve','reason':'Owner authorization and simulation-only rules verified.'})
    assert r.status_code==200,r.text


def grant(client,scope,red):
    r=client.post('/api/governance/scopes/'+scope+'/grants',headers=red,
        json={'asset_id':'lab-01','playbook_id':'process-telemetry'})
    assert r.status_code==201,r.text
    return r.json()['authorization_token']


def test_approval_grant_one_use_and_detection_correlation(client,auth):
    scope,admin,red,white=setup_scope(client,auth)
    assert client.post('/api/governance/scopes/'+scope+'/grants',headers=red,
        json={'asset_id':'lab-01','playbook_id':'process-telemetry'}).status_code==403
    approve(client,scope,white)
    token=grant(client,scope,red)
    response=client.post('/api/governance/exercises',headers=red,json={'authorization_token':token})
    assert response.status_code==202,response.text
    exercise=response.json()
    assert exercise['status']=='completed' and exercise['result']['synthetic'] is True
    assert client.post('/api/governance/exercises',headers=red,json={'authorization_token':token}).status_code==409
    detail=client.get('/api/governance/exercises/'+exercise['id'],headers=red).json()
    assert len(detail['telemetry'])==3
    event=detail['telemetry'][0]
    detection={'telemetry_id':event['id'],'source':'unit-test','external_id':'sample-1','provenance':'synthetic',
               'evidence':'Synthetic pipeline validation marker linked by exact event ID.','detected_at':now().isoformat()}
    assert client.post('/api/governance/detections',headers=red,json=detection).status_code==403
    assert client.post('/api/governance/detections',headers=admin,json=detection).status_code==201
    assert client.post('/api/governance/detections',headers=admin,json=detection).status_code==409
    metrics=client.get('/api/governance/correlation',headers=red).json()
    assert metrics['expected_events']==3 and metrics['matched_events']==1
    assert metrics['coverage_percent']==33.33 and len(metrics['gaps'])==2


def test_scope_revoke_before_worker_cancels_exercise(client,auth,monkeypatch):
    scope,admin,red,white=setup_scope(client,auth)
    approve(client,scope,white);token=grant(client,scope,red)
    import backend.app.api.governance as routes
    monkeypatch.setattr(routes,'drain_eager',lambda:None)
    response=client.post('/api/governance/exercises',headers=red,json={'authorization_token':token})
    assert response.status_code==202,response.text
    exercise_id=response.json()['id']
    assert client.post('/api/governance/scopes/'+scope+'/decisions',headers=white,
        json={'decision':'revoke','reason':'Exercise authorization has been withdrawn.'}).status_code==200
    with SessionLocal() as db:
        event_id=db.scalar(select(Outbox.id).where(Outbox.kind=='exercise.requested',Outbox.entity_id==exercise_id))
    process_event.run(event_id)
    with SessionLocal() as db: assert db.get(Exercise,exercise_id).status=='cancelled'


def test_self_approval_and_asset_scope_drift_are_denied(client,auth):
    scope,admin,red,white=setup_scope(client,auth)
    assert client.post('/api/governance/scopes/'+scope+'/decisions',headers=red,
        json={'decision':'approve','reason':'Trying to approve my own request.'}).status_code==403
    approve(client,scope,white)
    token=grant(client,scope,red)
    assert client.put('/api/assets/lab-01',headers=admin,json={**LAB,'internet_facing':True}).status_code==200
    assert client.post('/api/governance/exercises',headers=red,json={'authorization_token':token}).status_code==403


def test_unknown_playbook_and_wrong_grant_audience_are_denied(client,auth):
    scope,admin,red,white=setup_scope(client,auth)
    approve(client,scope,white)
    assert client.post('/api/governance/scopes/'+scope+'/grants',headers=red,
        json={'asset_id':'lab-01','playbook_id':'arbitrary-command'}).status_code==403
    assert client.post('/api/governance/exercises',headers=red,
        json={'authorization_token':red['Authorization'].split(' ',1)[1]}).status_code==403
