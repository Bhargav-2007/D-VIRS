import numpy as np
import pytest
from types import SimpleNamespace
from datetime import date
from backend.app.ml.features import materialize, FEATURES
from backend.app.ml.predict import artifact, predict
from backend.app.ml.explain import permutation_shapley
from backend.app.scoring.dynamic_score import score
from backend.app.scoring.contextual_score import DEFAULT_POLICY
from backend.app.scoring.priority_engine import priority


def test_rule_additivity_and_priority_boundaries():
    features = {k:0.5 for k in FEATURES}
    result = score(features, use_ml=False)
    e = result['explanation']
    assert result['score'] == 50
    assert sum(c['total_points'] for c in e['contributions']) == 50
    assert [priority(v,DEFAULT_POLICY['thresholds']) for v in [39.99,40,64.99,65,84.99,85]] == ['P3','P2','P2','P1','P1','P0']


def test_context_can_outweigh_cvss():
    internal = {k:0.0 for k in FEATURES}
    internal['cvss'] = 0.98
    exposed = {**internal,'cvss':0.65,'kev':1,'exposure':1}
    assert score(exposed,use_ml=False)['score'] > score(internal,use_ml=False)['score']
    assert score(exposed,use_ml=False)['priority'] == 'P0'


def test_hybrid_explanation_reconstructs_final_score():
    features = {k:0.6 for k in FEATURES}
    features.update(kev=1,exposure=1)
    result = score(features)
    e = result['explanation']
    reconstructed = e['baseline_points'] + sum(c['total_points'] for c in e['contributions']) + e['override_points']
    assert reconstructed == pytest.approx(result['score'], abs=0.0001)
    assert result['score'] >= 95
    assert result['probability'] is not None


def test_portable_shapley_reconciles_probability():
    features = dict(zip(FEATURES,[.8,.3,1,.8,1,1,.4,.2,.6,.4,1]))
    bundle = artifact()
    baseline, values = permutation_shapley(features, bundle)
    assert baseline + sum(values.values()) == pytest.approx(predict(features,bundle), abs=1e-5)


def test_missing_features_are_explicit_and_age_bounded():
    vuln = SimpleNamespace(cvss_v4=None,cvss_v3=None,epss=None,kev=False,exploit_available=False,
        threat_activity=0,published='bad',version=1,source_versions={})
    asset = SimpleNamespace(criticality=3,internet_facing=False,business_impact=3,data_sensitivity=3,environment='dev',version=1)
    values,sources = materialize(vuln,asset,date(2026,9,1))
    assert set(sources['missing']) == {'cvss','epss','published'}
    assert all(0<=v<=1 for v in values.values())


def test_score_bounds_random_inputs():
    rng = np.random.default_rng(9)
    for row in rng.random((100,len(FEATURES))):
        result = score(dict(zip(FEATURES,row)),use_ml=False)
        assert 0 <= result['score'] <= 100
