"""Train comparison artifacts and a selectable soft-voting defensive risk ensemble."""
import hashlib
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier, IsolationForest
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
from .features import FEATURES, SCHEMA
from .train import train
from .evaluate import metrics


def train_suite(csv=None):
    train(csv, 'ml/models/organization.joblib' if csv else 'ml/models/demo.joblib')
    train_data=pd.read_csv('ml/datasets/processed/train.csv')
    test_data=pd.read_csv('ml/datasets/processed/test.csv')
    x=train_data[FEATURES].to_numpy();y=train_data.exploited.to_numpy()
    test_x=test_data[FEATURES].to_numpy()
    xgb=XGBClassifier(n_estimators=100,max_depth=3,learning_rate=.06,random_state=42,n_jobs=2,eval_metric='logloss')
    lgbm=LGBMClassifier(n_estimators=100,max_depth=3,num_leaves=7,learning_rate=.06,random_state=42,n_jobs=2,verbosity=-1)
    forest=RandomForestClassifier(n_estimators=80,max_depth=6,min_samples_leaf=5,random_state=42,n_jobs=2)
    models={
        'logistic':LogisticRegression(max_iter=1000,random_state=42),
        'random-forest':forest,
        'lightgbm':lgbm,
        'gradient-boosting':GradientBoostingClassifier(n_estimators=80,max_depth=3,random_state=42),
        'ensemble':VotingClassifier(estimators=[('xgboost',xgb),('lightgbm',lgbm),('random_forest',forest)],
                                    voting='soft',weights=[.5,.25,.25])
    }
    background=train_data[FEATURES].sample(min(64,len(train_data)),random_state=42).to_numpy()
    source_hash=hashlib.sha256(train_data.to_csv(index=False,lineterminator='\n').encode()).hexdigest()[:12]
    report={'synthetic':csv is None,'note':'Synthetic held-out probability comparison, not proof of real-world effectiveness. Ensemble weights fixed before evaluation.','models':{}}
    destination=Path('ml/models');destination.mkdir(parents=True,exist_ok=True)
    for name,model in models.items():
        model.fit(x,y)
        path=destination/(name+'.joblib')
        bundle={'model':model,'features':FEATURES,'schema':SCHEMA,'version':f'{"organization" if csv else "synthetic"}-{name}-{source_hash}',
                'synthetic':csv is None,'background':background,'model_kind':name}
        bundle['version'] += '-' + joblib.hash(model)[:8]
        joblib.dump(bundle,path)
        manifest={k:bundle[k] for k in ('features','schema','version','synthetic','model_kind')}
        manifest['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        path.with_suffix('.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        report['models'][name]=metrics(test_data.exploited,model.predict_proba(test_x)[:,1],50,test_data.cvss)
    anomaly=IsolationForest(n_estimators=100,contamination=.05,random_state=42,n_jobs=2).fit(x)
    joblib.dump({'model':anomaly,'features':FEATURES,'schema':SCHEMA,'synthetic':csv is None,
                 'version':'synthetic-anomaly-'+source_hash},destination/'anomaly.joblib')
    report['anomaly']={'method':'Isolation Forest','training_contamination':.05,'synthetic':csv is None,
                       'note':'Contextual outlier score only. Never modifies vulnerability priority.'}
    Path('ml/experiments/model-suite.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'trained':list(models),'anomaly':True,'synthetic':csv is None},indent=2))
    return report


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--csv')
    train_suite(parser.parse_args().csv)
