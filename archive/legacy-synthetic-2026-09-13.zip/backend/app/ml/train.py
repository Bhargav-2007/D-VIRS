import argparse
import hashlib
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from xgboost import XGBClassifier
from .features import FEATURES, SCHEMA


def synthetic_dataset(n=2400, seed=42):
    rng = np.random.default_rng(seed)
    x = pd.DataFrame(rng.random((n, len(FEATURES))), columns=FEATURES)
    for k in ('kev', 'exposure', 'exploit', 'production'):
        x[k] = (x[k] > (0.82 if k == 'kev' else 0.5)).astype(float)
    x['epss'] = rng.beta(0.6, 3, n)
    logits = -5 + 1.1*x.cvss + 3*x.epss + 1.8*x.kev + 1.5*x.exposure + 1.2*x.threat + 0.7*x.exploit
    x['exploited'] = rng.binomial(1, 1/(1+np.exp(-logits)))
    x['cve_group'] = [f'synthetic-{i//3}' for i in range(n)]
    return x


def train(csv=None, output='ml/models/demo.joblib'):
    data = pd.read_csv(csv) if csv else synthetic_dataset()
    required = FEATURES + ['exploited', 'cve_group']
    if any(c not in data for c in required): raise ValueError(f'Required columns: {required}')
    if data[required].isnull().any().any(): raise ValueError('Missing training values')
    if not data[FEATURES].apply(lambda col: col.between(0, 1).all()).all(): raise ValueError('Features must be normalized to [0, 1]')
    for key in ('kev','exposure','exploit','production'):
        if not set(data[key].unique()).issubset({0,1}): raise ValueError(f'{key} must be binary')
    if set(data.exploited.unique()) != {0, 1}: raise ValueError('Both binary label classes required')
    train_idx, test_idx = next(GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=42).split(data, groups=data.cve_group))
    train_data, test_data = data.iloc[train_idx], data.iloc[test_idx]
    if set(train_data.exploited.unique()) != {0,1}: raise ValueError('Training split needs both label classes; supply more independent CVE groups')
    model = XGBClassifier(n_estimators=100, max_depth=3, learning_rate=0.06, subsample=0.9,
                          colsample_bytree=0.9, random_state=42, n_jobs=2, eval_metric='logloss')
    model.fit(train_data[FEATURES].to_numpy(), train_data.exploited.to_numpy())
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    version = ('synthetic-demo-' if csv is None else 'organization-') + hashlib.sha256(data.to_csv(index=False, lineterminator='\n').encode()).hexdigest()[:12]
    version += '-' + joblib.hash(model)[:8]
    bundle = {'model': model, 'features': FEATURES, 'schema': SCHEMA, 'version': version,
              'synthetic': csv is None, 'background': train_data[FEATURES].sample(min(64, len(train_data)), random_state=42).to_numpy()}
    joblib.dump(bundle, path)
    manifest = {k: bundle[k] for k in ('features', 'schema', 'version', 'synthetic')}
    manifest.update({'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'split': 'CVE-group-disjoint 75/25, seed 42',
                     'train_rows': len(train_data), 'test_rows': len(test_data), 'warning': 'Synthetic evaluation does not establish real-world effectiveness.' if csv is None else 'Validate temporal leakage, calibration and external generalization before promotion.'})
    path.with_suffix('.json').write_text(json.dumps(manifest, indent=2))
    datasets = Path('ml/datasets/processed')
    datasets.mkdir(parents=True, exist_ok=True)
    train_data.to_csv(datasets / 'train.csv', index=False)
    test_data.to_csv(datasets / 'test.csv', index=False)
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--csv')
    parser.add_argument('--output', default='ml/models/demo.joblib')
    args = parser.parse_args()
    print(json.dumps(train(args.csv, args.output), indent=2))
