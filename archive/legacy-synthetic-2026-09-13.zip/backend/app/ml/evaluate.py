import argparse
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import f1_score, roc_auc_score, average_precision_score
from .features import FEATURES
from ..scoring.contextual_score import DEFAULT_POLICY
from ..scoring.priority_engine import safety_floor


def metrics(y, scores, k, cvss_scores):
    y, scores = np.asarray(y), np.asarray(scores)
    k = min(max(1, k), len(y))
    order = np.argsort(-scores, kind='stable')
    top = y[order[:k]]
    positives = int(y.sum())
    target = max(1, int(np.ceil(positives * 0.8)))
    def workload(s):
        hits = np.cumsum(y[np.argsort(-s, kind='stable')])
        return int(np.searchsorted(hits, target) + 1) if positives else len(y)
    baseline_work = workload(np.asarray(cvss_scores))
    return {
        'k': k, 'precision_at_k': float(top.mean()), 'recall_at_k': float(top.sum()/positives) if positives else None,
        'f1': float(f1_score(y, scores >= 0.65, zero_division=0)),
        'roc_auc': float(roc_auc_score(y, scores)) if len(set(y)) == 2 else None,
        'pr_auc': float(average_precision_score(y, scores)) if positives else None,
        'ranking_correlation': float(spearmanr(scores, y).statistic) if len(set(y)) > 1 and len(set(scores)) > 1 else None,
        'top_k_exploited_hit_rate': float(top.mean()), 'false_priority_rate': float(1-top.mean()),
        'workload_to_80pct_recall': workload(scores) if positives else None,
        'remediation_workload_reduction': float(1-workload(scores)/baseline_work) if positives else None,
    }


def evaluate(csv='ml/datasets/processed/test.csv', model='ml/models/demo.joblib', k=50):
    data = pd.read_csv(csv)
    bundle = joblib.load(model)
    x = data[FEATURES]
    cvss = x.cvss.to_numpy()
    base = sum(x[key].to_numpy()*w for key, w in DEFAULT_POLICY['weights'].items()) / 100
    hybrid = 0.75*base + 0.25*bundle['model'].predict_proba(x.to_numpy())[:, 1]
    for i, row in enumerate(x.to_dict('records')):
        hybrid[i] = max(hybrid[i], safety_floor(row)[0]/100)
    approaches = {'CVSS only': cvss, 'CVSS + EPSS': 0.5*cvss + 0.5*x.epss.to_numpy(),
                  'CVSS + EPSS + KEV': 0.35*cvss+0.35*x.epss.to_numpy()+0.3*x.kev.to_numpy(), 'Dynamic risk': hybrid}
    result = {'synthetic': bundle['synthetic'], 'model_version': bundle['version'], 'samples': len(data),
              'label_prevalence': float(data.exploited.mean()), 'threshold': 0.65,
              'note': 'Held-out synthetic labels; not evidence of production effectiveness. Hit rate equals Precision@K; correlation is Spearman against binary labels.',
              'approaches': {name: metrics(data.exploited, values, k, cvss) for name, values in approaches.items()}}
    dest = Path('ml/experiments/evaluation.json')
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(result, indent=2, allow_nan=False))
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--csv', default='ml/datasets/processed/test.csv')
    p.add_argument('--model', default='ml/models/demo.joblib')
    p.add_argument('--k', type=int, default=50)
    a = p.parse_args()
    print(json.dumps(evaluate(a.csv, a.model, a.k), indent=2))
